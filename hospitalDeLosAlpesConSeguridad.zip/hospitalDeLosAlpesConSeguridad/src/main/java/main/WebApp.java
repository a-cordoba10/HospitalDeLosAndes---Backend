package main;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("/app")
public class WebApp extends ResourceConfig {
	public WebApp(){
        packages("Resources");
    }
}